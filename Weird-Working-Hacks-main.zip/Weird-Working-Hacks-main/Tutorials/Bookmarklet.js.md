
# How to use the bookmarklets.js

1. Copy the entire thing using the two box looking things in the corner of the bar over the code

2. Click on the boxes and it will become a checkmark

3. Go up to the bookmark star

4. Click on it

5. Go to More...

6. Go to URL

7. Paste it there

8. Press Save

9. You're done!
