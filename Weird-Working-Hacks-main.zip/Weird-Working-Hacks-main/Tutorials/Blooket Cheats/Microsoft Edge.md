# 1. Navigate to `obfuscated` folder

# 2. Open `Bookmarklets.html` file

# 3. Click `Download` or `View raw`

# 4. Ctrl + S or Right click > Save as

# 5. Save file

# 6. Right click on favorites bar and click Manage Favorites

# 7. Click on the three dots > Import favorites

# 8. Import from IE11

# 9. Switch to `Favorites or bookmarks HTML file`

# 10. Click on `Choose File`

# 11. Choose the saved file from step 5

# 12. Go back to favorites page and create a new folder

# 13. Open `Other favorites` folder and select all (Ctrl + A)

# 14. Drag to folder created in step 12

# 15. Happy cheating
