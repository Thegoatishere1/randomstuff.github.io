# 1. Navigate to `obfuscated` folder

# 2. Open `Bookmarklets.html` file

# 3. Click `Download` or `View raw`

# 4. Ctrl + S or Right click > Save as

# 5. Save file

# 6. Click on the three dots in the top right > Bookmarks > Import bookmarks and settings **OR** do `Ctrl + Shift + O` > three dots in the top right > import

# 7. Switch to `Bookmarks HTML File`

# 8. Click on `Choose File`

# 9. Choose the saved file from step 5

# 10. Happy cheating
