# WeirdWorkingHacks
The best Hacks for everything out there

# Blooket Hacks fixed Thanks!

DO NOT EDIT, OR ELSE!!
PLEASE

Hacks For everything you Need Them For 

# I give full credit for the Blooket and Gimkit cheats to Aerell and TheLazySquid. I just wanted them to be in another place too.

<p align="center">Blooket Cheats</p>

<p align="center">Cheats made by someone who knows more about what they're doing</p>
<h3 align="center"><a href="https://github.com/RONAKPATELLLLLLL/WeirdWorkingHacks/tree/main/Tutorials/Blooket%20Cheats">Instructions for importing bookmarklets</a></h2>

# Vision Board

- [ ] Auto Play
- [ ] GUI ingame chat for cheaters? (Low chance of this happening)
- [ ] More Racing cheats
- [ ] Change name during game
- [ ] Set players gold/crypto

## Information

<details><summary><h3>How to use</h3></summary>

There are 3 good methods to using these scripts:
1. Importing one of the Bookmarklets.html files using [these instructions](https://github.com/RONAKPATELLLLLLL/WeirdWorkingHacks/tree/main/Tutorials/Blooket%20Cheats)
2. Going to the [GitHub pages site](https://minesraft2.github.io/Blooket-Cheats), choosing a gamemode, then dragging a cheat to your bookmarks bar or clicking one to copy the script
3. Copying a script and running it in the inspect element console
</details>

<details><summary><h3>What can I do if JavaScript is blocked?</h3></summary>

We don't actually know what to do about this or how to fix it, sorry.
</details>

<details><summary><h3>(script) is not working?</h3></summary>

Make sure you're running it properly, if it still doesn't work and other cheats do, then make an issue
</details>

<details><summary><h3>What is the difference between obfuscated and unobfuscated?</h3></summary>

Obfuscated are scripts that are changed to be unreadable, unobfuscated are the original scripts (both with an added update checker).
Unobfuscated scripts will not work if you try copying it and pasting it into a bookmarklet. This is because of the lack of semicolons in certain places. Please either use the obfuscated scripts or use one of the methods mentions in the first FAQ
</details>

<details><summary><h3>Can you give me infinite tokens / bypass daily limit / permanently give me blooks / change pack luck?</h3></summary>

No, these are things we would've already done if they were possible, they're managed on the backend of Blooket so we can't modify them
</details>

<details><summary><h3>Can you make hacks for (game)</h3></summary>

I'll start making scripts for other games when the Blooket scripts stop needing so much maintenance
</details>

<details><summary><h3>Can you make more Battle Royale cheats</h3></summary>

Battle Royale is a gamemode that works almost entirely on the host's end. The only thing we have control over is answering questions.
</details>

<details><summary><h3>How do I do this on mobile?</h3></summary>

These scripts aren't made for mobile, so we don't really know how to get them to work on it.
</details>

<details><summary><h3>What's the Mobile GUI?</h3></summary>

The mobile GUI is the original GUI I made long ago. Some people said it worked on mobile and it's a lot neater for mobile use apparently so we just called it that.
</details>


<details><summary><h2>List of Cheats</h2></summary>

* [GUI]
* [Mobile GUI]
### [Monster Brawl]
* [Double Enemy XP]
* [Half Enemy Speed]
* [Instant Kill]
* [Invincibility]
* [Kill Enemies]
* [Magnet]
* [Max Current Abilities]
* [Next Level]
* [Remove Obstacles]
* [Reset Health]
### [Cafe]
* [Max Items]
* [Remove Customers]
* [Reset Abilities]
* [Set Cash]
* [Stock Food]
### [Crypto Hack]
* [Always Triple]
* [Auto Guess] 
* [Choice ESP]
* [Password ESP]
* [Remove Hack]
* [Set Crypto]
* [Set Password]
* [Steal Players Crypto]
### [Deceptive Dinos]
* [Auto Choose]
* [Rock ESP]
* [Set Fossils]
* [Set Multiplier]
* [Stop Cheating]
### [Tower of Doom]
* [Fill Deck]
* [Max Cards]
* [Max Health]
* [Max Stats]
* [Min Enemy]
* [Set Coins]
### [Factory]
* [Choose Blook]
* [Max Blooks]
* [Remove Glitches]
* [Send Glitch]
* [Set All Mega Bot]
* [Set Cash]
### [Fishing Frenzy]
* [Frenzy]
* [Remove Distraction]
* [Send Distraction]
* [Set Lure]
* [Set Weight]
### [Flappy Blook]
* [Set Score]
* [Toggle Ghost]
### [Global]
* [Anti Flood Game]
* [Auto Answer]
* [Auto Sell Dupes On Open]
* [Every Answer Correct]
* [Flood Game]
* [Get Daily Rewards]
* [Highlight Answers]
* [Prevent Suspension]
* [Remove Random Name]
* [Sell Cheap Duplicates]
* [Sell Duplicate Blooks]
* [Simulate Pack]
* [Simulate Unlock]
* [Spam Buy Blooks]
* [Unlock Plus Gamemodes]
* [Use Any Blook]
#### [Intervals]
* [Auto Answer]
* [Highlight Answers]
### [Gold Quest]
* [Always Triple]
* [Auto Choose]
* [Chest ESP]
* [Reset All Gold]
* [Reset Players Gold]
* [Set Gold]
* [Swap Gold]
### [Crazy Kingdom]
* [Choice ESP]
* [Choice ESP Loop]
* [Disable Toucan]
* [Max Stats]
* [Set Guests]
* [Skip Guest]
### [Battle Royale]
* [Auto Answer]
#### [Intervals]
* [Auto Answer]
### [Blook Rush]
* [Set Blooks]
* [Set Defense]
### [Tower Defense]
* [Earthquake]
* [Max Towers]
* [Remove Ducks]
* [Remove Enemies]
* [Remove Obsticles]
* [Set Damage]
* [Set Round]
* [Set Tokens]
### [Tower Defense 2]
* [Max Towers]
* [Remove Enemies]
* [Set Coins]
* [Set Health]
* [Set Round]
### [Santa's Workshop]
* [Remove Distractions]
* [Send Distraction]
* [Set Toys]
* [Set Toys Per Question]
* [Swap Toys]
</details>

[^1]: [Overtime](https://github.com/overtimepog)

# Gimkit Cheat

## Usage

When in a Gimkit game, open the console (Ctrl+Shift+I) and paste the code for your desired gamemode after setting up an override. Read below for more information for each gamemode.

## All scripts now require a local override to be set up. Click [here](#setting-up-the-overrides) to see how to set up a local override. If you are unable to use local overrides, you can use the old version that doesn't require an override. You will need to answer all questions once before it begins working.

## General Use Scripts

### [Auto answer]

This script automatically answers a question every ~1 second. Manually answering questions may cause them to be wrong even if they looked correct.

### [Player Higlighter]

This script adds toggles that allow you to highlight where teammates and enemies are in relation to you. This is useful for games like Capture the Flag, Snowbrawl or Tag.

### [Cosmetic Picker]

This script allows you to select any cosmetic you want, including unused ones such as clown. Nobody else can see the equipped cosmetics, they are only visible to you.

### [Freecam]

This script allows you to move your camera independent of your player. When in freecam mode, you can move the camera by hitting u, h, j and k. If i'm gonna be honest, it's not actually that useful, but it's still a neat utility to have.

## Gamemode Specific Scripts

### [Classic]

The trick for classic is loosely based around a trick found in [non-reai's Gimkit hack](https://github.com/non-reai/Gimkit-Hacks) to answer questions, rather than manually storing and answering questions. It automatically answers questions and purchases upgrades, and all you should manually do is purchase and use powerups.

### [Fishtopia]

This script allows you to sell fish without being at the sell station and fish anywhere without being at water. Additionally, after using a "travel to..." thing (such as the travel to purple pond boat), you will be able to permanently use it from anywhere.

### [One Way Out]

#### Patched: You can no longer use auto attack

This script allows you to do a variety of things. First, you can purchase health, shield, bridges and checkpoints from anywhere. Secondly, it comes with an "Auto Attack" feature. While holding a weapon out, it will automatically fire it and kill the nearest enemy to you, even through walls. This lets you earn the money from killing enemies from anywhere, so you can simply loiter at spawn doing this until you can afford to get the third checkpoint. You need to purchase the bridge before the checkpoint, like normal.

### [Farmchain]

This script does the standard stuff of getting water, research, seeds and unlocks from anywhere. On top of that, it comes with an "auto harvest" mode which will automatically collect grown crops from wherever, and an auto plant mode. Auto plant mode automatically will plant all seeds in your inventory from wherever you are, which can then be harvested with auto harvest. Once you begin using this, all you need to do is purchase and unlock seeds for it to plant.

### [Capture the flag]

This script allows you to purchase upgrades and invisabits from anywhere. In the future it might highlight where opponents are, but that's still in the works.

### [Tag]

For now, all this lets you do is buy upgrades from anywhere. As with capture the flag, more is in the works.

### [Snowbrawl]

#### Patched: You can no longer use auto attack

This script allows you to buy health and med packs from anywhere, but more importantly, it has an "Auto Attack" button. This allows will automatically damage and quickly kill the nearest player to you. Unlike in no way out, you really are attacking real players with this one and you effectively softlock the game in smaller lobbies. Please be responsible when using this.


## Updating the override

In order to update the overrides, simply redownload the overrides and replace the old ones.

# Gimkit Cheat

This version of Gimkit Cheat was inspired by Gimkit Utility by [UndercoverGoose](https://github.com/UndercoverGoose), which was sadly taken down. The main things that were carried over from the other script are using Typescript, Rollup and Tampermonkey, which makes it easier to develop and use. If you do want to try out the older versions, check out v2.

Install/Update it by clicking on [this link](https://raw.githubusercontent.com/TheLazySquid/GimkitCheat/main/build/bundle.user.js) while having [Tampermonkey](https://www.tampermonkey.net/) installed on your browser.

## Features

Gimkit Cheat provides a nice, unified way to use different cheats. To open/close the hud, press "\" (backslash) on your keyboard while on Gimkit. It will show various menus, which should be fairly self explanatory. While it might look like a lot is missing, this script includes all still-working features from the old one. Which is to say, not a lot, since Gimkit patched almost everything out.

### General Cheats

- **Auto Answer**: Automatically answers questions for you.
- **Cosmetic Picker**: Allows you to use any cosmetic you want, even unused ones. These are only visible to you.
- **Freecam**: Allows you to move your camera wherever you want, or even spectate other players. Once in freecam, use UHJK to move around.
- **Player Highlighter**: Marks on your screen where teammates or enemies are in relation to you.
- **Instant Use**: Tired of waiting for painfully slow bars to fill up just to purchase something minor? This allows you to use the nearest thing instantly by hitting enter.

### Gamemode Specific Cheats

- **Classic**: Automatically purchases upgrades for you. Best used with Auto Answer.
- **Super Rich Mode**: Identical to Classic, with adjusted values.
- **Trust No One**: Tells you who the imposters are. Doesn't work if you join mid-game.
- **Capture The Flag**: Purchase upgrades from anywhere
- **Tag**: Purchase upgrades from anywhere
- **Snowbrawl**: Purchase shield cans/medpacks from anywhere
- **One Way Out**: Purchase shield cans/medpacks from anywhere
- **Farmchain**: Adds options to automatically harvest/plant crops from anywhere

and more to come!

